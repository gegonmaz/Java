package p3;
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E2 {    
	//.........................................................................
	//.........................................................................
	public static void main (String[] args) {
		// pruebas de la clase Conjunto            
            //-----------------------1ºprueba-------------------------------
            Conjunto c1=new Conjunto();            
            System.out.println("el tamaño es:" + c1.talla());
            c1.anyadir(4);
            c1.anyadir(6);
            c1.anyadir(7.5);
            System.out.println("el tamaño es:" + c1.talla());
            c1.vaciar();
            System.out.println("el tamaño es:" + c1.talla());
            //-------------------------2ºprueba-----------------------------
            c1.anyadir(4.0);
            c1.anyadir(6.0);
            c1.anyadir(7.5);
            c1.anyadir(8.9);
            c1.anyadir(32.0);
            c1.anyadir(50.0);
            c1.anyadir(24.0);
            boolean esta=c1.contiene(Utilidades.leerReal("Dime un real"));
            boolean esta2=c1.contiene(Utilidades.leerReal("Dime otro real"));
            System.out.print("Esta el primer numero en elementos: " + esta);
            System.out.println(" Esta el segundo numero en elementos: " + esta2);
            //-------------------------3ºprueba------------------------------
            Conjunto c2=new Conjunto();
            c2.anyadir(50.0);
            c2.anyadir(50.0);//prueba de que no tiene que dar error,y que no hara nada 
                             //con el porque ya lo contiene el elemento
            c2.anyadir(-45);
            c2.anyadir(83);
            c2.eliminar(83);
            Conjunto c3=c1.unir(c2);
        } // ()

} // class
