package p3;
/*
 * @author Gema
 */
public class E3 {

    public static void main(String[] args) {
        Conjunto e1= new Conjunto();
        Conjunto e2= new Conjunto();
        
        e1.anyadir(3.0);
        e1.anyadir(4.0);
        e1.anyadir(5.0);
        e1.anyadir(6.0);
        e1.anyadir(7.0);
        e1.anyadir(8.0);
        e2.anyadir(7.0);
        e2.anyadir(8.0);
        e2.anyadir(9.0);
        e2.anyadir(10.0);
        e2.anyadir(3.0);
        e2.anyadir(4.0);
        
        Conjunto e3=new Conjunto();
        e3=e1.interseccion(e2);
        Conjunto e4=e1.diferencia(e2);
        Conjunto e5=e1.diferenciaSimetrica(e2);
        System.out.println("Los elementos del conjunto: " + e3);
        System.out.println("Los elementos del conjunto: " + e4);
        System.out.println("Los elementos del conjunto: " + e5);
        e5.mayorQue(3);
        double n5=e5.suma();
        
    }
}
