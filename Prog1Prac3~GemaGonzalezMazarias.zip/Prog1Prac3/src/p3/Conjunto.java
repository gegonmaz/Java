package p3;
//Gema González Mazarías
//------------------------------------------------------------------------------
import java.util.ArrayList;
// Completar la implementacion de la clase
public class Conjunto {
    //static, porque el valor de la variable no cambia, se va a mantener igual
    private static int NO_ESTA = -1;
    private ArrayList<Double> elementos;

    //.........................................................................
    /*
     * Constructor por defecto,inicializara la estructura interna de la clase
     */
    public Conjunto() {
        elementos = new ArrayList<Double>();
    } // ()          //|constructor de la clase arraylist|

    //----------------------------------------------------------------------
     public void vaciar()
    {
        elementos.clear();
    }
    
    //--------------------------------------------------------------------------
      public int talla() 
    {
        return (elementos.size());
    }

    //----------------------------------------------------------------------
      private int donde(double elem)
    {                //i<=talla()-1
        for(int i=0;i<=elementos.size()-1;i++)
        {
            if(elementos.get(i)==elem)
            {
                 return i;//finaliza la funcion
                          //devuelve lo que quieras
            }           
        } 
       return NO_ESTA;
    }

    //.........................................................................
      public boolean contiene(double elem) 
    {
       int pos=donde(elem);
       if(pos==NO_ESTA)
       {
           return false;
       }
       else
       {
       return true;
       }
    }
    
    //--------------------------------------------------------------------------  
    public void anyadir(double elem) 
    {
      if(contiene(elem)==false)
      {
          elementos.add(elem);
      }
    }

    //----------------------------------------------------------------------   
    public void eliminar(double elem)
    {
        /*
         * Para poder utilizar remove,tengo que saber en que posicion se encuentra,
         * por ello tenemos que utilizar donde() que es la funcion que me devuelve 
         * la posicion del elemento
         */
       int pos=donde(elem);
       if(pos!=NO_ESTA)
       {
           elementos.remove(pos);//(pos)donde tengo guardado el indice del elemto
       }
    }
    
    //--------------------------------------------------------------------------
    public Conjunto unir(Conjunto h)
    {
       Conjunto u=new Conjunto();
       //1º añadimos los elemntos de h(Conjunto que le paso)
       for (int i=0;i<=h.talla()-1;i++)
       {
           u.anyadir(h.elementos.get(i));
       }
       //2º añadimos los elementos de mi conjunto
       for(int j=0;j<=talla()-1;j++)
       {
           u.anyadir(elementos.get(j));
       }
       return u;
    }
    
    //--------------------------------------------------------------------------
   
   
    public String aTexto() {
        StringBuilder texto = new StringBuilder();

        for (double v : elementos) {
            texto.append(" ").append(v);
        }

        return texto.toString();
    } // ()
    //.........................................................................
    //Complementar la clase con los métodos optativos    
     public Conjunto interseccion (Conjunto b)
     {
         Conjunto n1=new Conjunto();
         double elems;
         //1º recorremos uno de los conjuntos
         //recorremos nuestros elementos
         for(int i=0;i<=talla()-1;i++)
         {
             //comparamos los nº de nuestro conjunto con los del conjunto b
             elems=elementos.get(i);
             if(b.contiene(elems)==true)
             {
                 //añadimos los que sean comunes a ambos conjuntos
                 n1.anyadir(elems);
             }
         }
         
         return n1;
     }
   
     //------------------------------------------------------------------------
     
     public Conjunto diferencia (Conjunto b)
     {
         Conjunto n1=new Conjunto();
         double elems;
         //1º recorremos uno de los conjuntos
         //recorremos nuestros elementos
         for(int i=0;i<=talla()-1;i++)
         {
             //comparamos los nº de nuestro conjunto con los del conjunto b
             elems=elementos.get(i);
             if(b.contiene(elems)==false)
             {
                 //añadimos los que no esten en el conjunto b
                 n1.anyadir(elems);
             }
         }
         
         return n1;
     }
     //-------------------------------------------------------------------------
     
     public Conjunto diferenciaSimetrica(Conjunto b)
     {
         Conjunto uni=this.unir(b);
         Conjunto intr=this.interseccion(b);
         Conjunto difSimet=uni.diferencia(intr);
         return difSimet;
         
     }
     
     //------------------------------------------------------------------------
     public double suma()
     {
         double s=0.0;
         for(double x:elementos)
         {
             s=s+x;
         }
         return s;
     }
     
     //------------------------------------------------------------------------
     
     //método de la evaluación de la practica 3
     
     public boolean menorPorProducto (Conjunto otro)
     {
         double producto1=1.0;//lo inicializamos a 1 porque tiene que multiplicar
         double producto2=1.0;
                 
         for(int i=0;i<=talla()-1;i++)//recorre los elementos de mi conjunto
         {
            producto1=producto1*elementos.get(i);
         }
          for (int j=0;j<=otro.elementos.size()-1;j++)//recorro los elementos del otro conjunto
         {
             producto2=producto2*(otro.elementos.get(j));
         }
         if(producto1<producto2)
         {
             return true;
         }
         else
         {
             return false;
         }
     }
     
     //-------------------------------------------------------------------------
     
     public Conjunto mayorQue(double r)
     {
         Conjunto may=new Conjunto();
         for(double x:this.elementos)
         {
             if(r<x)
             {
                 may.anyadir(x);
             }
         }
         return may;
     }
    
} // class Conjunto
