package p3;
import java.util.ArrayList;
//------------------------------------------------------------------------------
public class E1 {	
	//.........................................................................
	public static void main (String[] args) {
         //creamos un ArrayList de enteros vacio(La declaracion nos pide clases)
		ArrayList<Integer> numeros = new ArrayList<Integer> ();
		numeros.add(23);
		numeros.add(-40);
		numeros.add(14);
		for (int i = 0; i<=numeros.size()-1; i++) {
			numeros.set(i, numeros.get(i)*2);
		}
		Utilidades.muestraArrayList ("contenido (1):", numeros);
		numeros.add(1, 1234);
		Utilidades.muestraArrayList ("contenido (2):", numeros);
		numeros.set(1, 2345);
		Utilidades.muestraArrayList ("contenido (3):", numeros);
		numeros.remove(2);
		Utilidades.muestraArrayList ("contenido (4):", numeros);
		numeros.clear();
		Utilidades.muestraArrayList ("contenido (5):", numeros);
	} // ()
} // class
