
package p3;

/**
 *
 * @author Gema
 */
public class E4Evaluacion {
    public static void main(String[]args)
    {
        //------------1ºprueba-----------
        //int l1=Utilidades.leerEntero("Cuantos elementos quieres en el primer conjunto");
        Conjunto c1=new Conjunto();
        Conjunto c2=new Conjunto();
        boolean menorEstricto;
        c1.anyadir(1.0);
        c1.anyadir(2.0);
        c1.anyadir(-3.0);
        c2.anyadir(-3.0);
        c2.anyadir(1.0);
        c2.anyadir(2.0);
        
        /*for(int i=0;i<=l1-1;i++)
        
        {
            c1.anyadir(Utilidades.leerReal("dime un numero"));
            
        }
        
        int l2=Utilidades.leerEntero("Cuantos elementos quieres en el segundo conjunto");
        for(int j=0;j<=l2-1;j++)
        {
            c2.anyadir(Utilidades.leerReal("dime un numero"));
        }*/
        
        menorEstricto=c1.menorPorProducto(c2);
        System.out.println("el elemento es menor estricto: " + menorEstricto);
        
        //--------------2ºprueba-------------------
        Conjunto c3=new Conjunto();
        Conjunto c4=new Conjunto();
        boolean menorEstricto2;
        c3.anyadir(1.0);
        c3.anyadir(2.0);
        c3.anyadir(-3.0);
        c4.anyadir(1.0);
        c4.anyadir(4.0);
        c4.anyadir(3.0);
        menorEstricto2=c3.menorPorProducto(c4);
        System.out.println("el elemento es menor estricto: " + menorEstricto2);
        
    }
    
    
}
