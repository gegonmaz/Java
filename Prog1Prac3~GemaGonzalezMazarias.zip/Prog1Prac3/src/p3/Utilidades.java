package p3;

import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.ArrayList;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
public class Utilidades {

	//.........................................................................
	//.........................................................................
	public static int leerEntero (String mensaje) {

		int v = Integer.parseInt( JOptionPane.showInputDialog(mensaje) );

		return v;
	} // ()

	//.........................................................................
	//.........................................................................
	public static double leerReal (String mensaje) {

		return  Double.parseDouble( JOptionPane.showInputDialog(mensaje) );
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraMensaje (String mensaje) {

		JOptionPane.showMessageDialog(null, mensaje);
	} // ()

	//.........................................................................
	//.........................................................................
	public static double[] leerArrayDeReales (String mensaje) {

		// leo un texto
		String loLeido = JOptionPane.showInputDialog(mensaje) ;

		// el Scanner me sacara los numeros de uno en uno con .nextDouble()
		// el separador enteros/decimanes sera el punto (como en US)
		Scanner troceador = new Scanner (loLeido).useLocale(java.util.Locale.US);

		// para guardarlos necesito un vector porque no se cuantos hay
		ArrayList<Double> almacen = new ArrayList<Double> ();

		double x;

		// saco los numeros del string, mientras haya
		while ( troceador.hasNextDouble() ) {
			x = troceador.nextDouble();
			almacen.add(x);
		}

		// ahora que ya los tengo y se cuantos hay
		// los copio del vector al array resultado
		double[] resultado = new double[almacen.size()];

		for (int i=0; i<=resultado.length-1; i++) {
			resultado[i] = almacen.get(i);
		}

		return resultado;
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraArrayList (String mensaje, ArrayList<?> vec) {

		StringBuffer texto = new StringBuffer (mensaje + "\n");

		for (Object o : vec) {
			texto.append(o).append(", ");
		}

		System.out.println (texto);

		JOptionPane.showMessageDialog(null, texto.toString());
	} // ()

} // class Utilidades
