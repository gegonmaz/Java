package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E4 {

    //.........................................................................
    // sumar 1+2+ ... + n
    //.........................................................................
    public static void main(String[] args) {

        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");
        int n = Integer.parseInt(JOptionPane.showInputDialog("Dime n"));
        int sum = 0;//la primera vez que utilicemos la variable suma valdra 0
        for (int i = 1; i <= n; i++) {//bucle de repetición
            sum = sum + i;
        }
        JOptionPane.showMessageDialog(null, " La suma es " + sum);
        System.out.println("La suma es " + sum);



    } // ()
} 
