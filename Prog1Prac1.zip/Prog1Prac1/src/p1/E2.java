package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E2 {

    //.........................................................................
    // lee un entero n y escribe 1,2,3, ..., n
    //.........................................................................
    public static void main(String[] args) {

        int n = Integer.parseInt(JOptionPane.showInputDialog("dime un entero"));

        for (int i = n; i >= 0; i = i - 1) { //bucle de repetición

            System.out.println("i");
            System.out.println(i);

        }
        System.out.println("ya he terminado");


    } // ()
} 