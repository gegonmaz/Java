package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E5 {

    //.........................................................................
    // lee un punto y muestra sus coordenadas
    //.........................................................................
    public static void main(String[] args) {

        double x = Double.parseDouble(JOptionPane.showInputDialog("dime la coordenada x"));
        //guardamos las coordenadas de x
        double y = Double.parseDouble(JOptionPane.showInputDialog("dime la coordenada y"));
        //guardamos las coordenadas de y
        Punto a = new Punto(x, y);
        //creamos el punto

        JOptionPane.showMessageDialog(null, " x = " + a.getX() + " y = " + a.getY());
        //mostramos el punto
    } // ()
} 
