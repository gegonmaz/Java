package p1;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
public class E8 {

    //.........................................................................
    // calcular la distancia de un camino de n puntos
    //.........................................................................
    public static void main(String[] args) {

        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");


        int n = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántos puntos quieres?"));
        //nº de puntos que queremos
        Punto a = Utilidades.leePunto();
        //pedimos las coordenadas del primer punto
        Utilidades.muestraPunto(a);
        //devolvemos el punto introducido
        double distancia;
        //inicializamos variable con valor de cero
        double sum = 0.0;
        //inicializamos variable a cero
        for (int i = 1; i <= n - 1; i++) {
            Punto a2 = Utilidades.leePunto();
            Utilidades.muestraPunto(a2);
            distancia = a.distancia(a2);
            Utilidades.muestraMensaje("La distancia entre los dos puntos es: " + distancia);
            sum = sum + distancia;
            a = a2;
            /*
             * pedimos un nuevo punto y calculamos la distancia del punto
             * anterior hasta el último punto introducido,una vez calculamos la
             * distancia, pasamos el valor del punto nuevo en el punto anterior
             * para no borrar su valor y poder calcular la distancia entre los
             * siguientes puntos,ya que sino,borrariamos el ultimo punto y no
             * podriamos calcular la distancia entre los dos puntos
             * correctamente.
             */
        }

        Utilidades.muestraMensaje("La distancia TOTAL de los puntos es:" + sum);



    } // ()
} 
