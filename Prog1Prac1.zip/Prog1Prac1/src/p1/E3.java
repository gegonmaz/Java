package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E3 {

    //.........................................................................
    // dice cuál es el mayor de n enteros
    //.........................................................................
    public static void main(String[] args) {

        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");

        /*
         * n es el número de enteros que queremos ordenar(pedimos n veces el
         * entero).
         */
        int n = Integer.parseInt(JOptionPane.showInputDialog("Dime cuantos n quieres"));
        //lee un entero y lo guarda en n
        int may = Integer.parseInt(JOptionPane.showInputDialog("Dime un entero"));
        //lee un entero y lo guarda en may;variable que guardara los mayores
        for (int i = 1; i <= n - 1; i++) { // bucle de repetición

            int a = Integer.parseInt(JOptionPane.showInputDialog("Dime un entero"));
            //leemos un entero y lo guardamos en a
            if (a > may) {
                may = a;
                /*comparamos los enteros guardados en (a) y (may),si el número
                 * que se encuentra guardado en (a) es mayor que el número guardado
                 * en (may),pasará a guardarse en may y volveremos a pedir otro
                 * entero que se guardara en (a) y se volvera a comparar;si (a) 
                 * no es mayor que (may) se quedara como esta y se volvera a pedir
                 * el valor de (a),con lo cual el que habia guardado ahi será 
                 * borrado por el valor nuevo.
                */
            }

        }
        JOptionPane.showMessageDialog(null, " El mayor es " + may);
        System.out.println("El mayor es " + may);

    } // ()
} 