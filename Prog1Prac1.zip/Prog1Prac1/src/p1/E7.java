
package p1;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E7 {

	//.........................................................................
	// muestra la distancia al origen de un punto
	//.........................................................................
	public static void main (String[] args) {

		Punto origen = new Punto (0.0, 0.0);

		Punto p  = Utilidades.leePunto();

		double d = origen.distancia(p);

		Utilidades.muestraMensaje("la distancia del origen a p es" + d);

	} // ()

} 
