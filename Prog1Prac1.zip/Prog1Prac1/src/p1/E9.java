/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import javax.swing.JOptionPane;

/**
 *
 * @author Gema González Mazarías
 */
public class E9 {
    //.........................................................................
            //Ejercicio Extra:
                //Hacemos el mismo ejercicio 8, pero en vez de con un for,lo 
                //hacemos con un while
    //.........................................................................
    public static void main(String[] args) {
        int n = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántos puntos quieres?"));
         Punto a = Utilidades.leePunto();
         //Utilidades.muestraPunto(a);
         double distancia;
         double sum = 0.0;
         int i=1;
         while(i<=n-1){
             Punto a2 = Utilidades.leePunto();
           // Utilidades.muestraPunto(a2);
            distancia = a.distancia(a2);
           // Utilidades.muestraMensaje("La distancia entre los dos puntos es: " + distancia);
            sum = sum + distancia;
            a = a2;
            i++;
             
         }
         Utilidades.muestraMensaje("La distancia TOTAL de los puntos es:" + sum);
    }

    
}
