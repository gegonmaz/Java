
package p1;
//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E6 {

	//.........................................................................
	// lee un punto y muestra sus coordenadas
	//.........................................................................
	public static void main (String[] args) {


		Punto a  = Utilidades.leePunto();
                //pedimos el punto 
		Utilidades.muestraPunto(a);
                //mostramos el punto

	} // ()

} 
