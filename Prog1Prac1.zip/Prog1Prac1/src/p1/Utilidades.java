package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
public class Utilidades {

	//.........................................................................
	//.........................................................................
	public static double leerEntero (String mensaje) {

		int v = Integer.parseInt( JOptionPane.showInputDialog(mensaje) );

		return v;
	} // ()

	//.........................................................................
	//.........................................................................
	public static double leerReal (String mensaje) {

		return  Double.parseDouble( JOptionPane.showInputDialog(mensaje) );
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraMensaje (String mensaje) {

		JOptionPane.showMessageDialog(null, mensaje);
	} // ()

	//.........................................................................
	//.........................................................................
	public static Punto leePunto () {

		double x = leerReal ( "dime coord. x");
		double y = leerReal ( "dime coord. y");

		Punto nuevo = new Punto (x, y);

		return nuevo;
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraPunto (Punto p) {

		JOptionPane.showMessageDialog(null, " x = " + p.getX() + " y = " + p.getY());

	} // ()

} // class Utilidades
