package p1;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
    //Gema González Mazarías
//------------------------------------------------------------------------------
public class E1 {

    //.........................................................................
    // lee dos enteros y dice cual es el mayor
    //.........................................................................
    public static void main(String[] args) {

        // lo siguiente lee un entero y lo guarda en a
        int a = Integer.parseInt(JOptionPane.showInputDialog("dime un entero"));

        // lo siguiente lee un entero y lo guarda en b
        int b = Integer.parseInt(JOptionPane.showInputDialog("dime otro entero"));

        // ahora declaro una variable que se llama mayor
        int mayor;

        if (a >= b) { //si... la variable a es mayor o igual que, la mayor será a
            mayor = a;
        } else { //sino la mayor será b
            mayor = b;
        }

        JOptionPane.showMessageDialog(null, "el mayor es " + mayor);
        //escribimos en pantalla(ventana)
        System.out.println("el mayor es " + mayor);
        //escribimos en consola

    } // ()
} 