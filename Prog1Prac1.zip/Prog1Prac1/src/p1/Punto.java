package p1;

//..............................................................................
//..............................................................................
public class Punto {

  private double x;
  private double y;

  public Punto () {
	  x = 0.0;
	  y = 0.0;
  } // ()

  public Punto (double x, double y) {
	this.x = x;
	this.y = y;
  } // ()

  public double getX ()  {
	return x;
  } // ()

  public double getY ()  {
	return y;
  } // ()

  public double distancia (Punto otro) {
	double dx = x - otro.x;
	double dy = y - otro.y;
	return Math.sqrt (dx*dx + dy*dy);
  } // ()

  public Punto suma (Punto otro) {
	Punto  nuevo = new Punto(x+otro.x, y+otro.y);
	return nuevo;
  } // ()

} // class
