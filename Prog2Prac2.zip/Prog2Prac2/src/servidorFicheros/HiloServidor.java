
package servidorFicheros;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import util.Utilidades;

/**
 *
 * @author Gema González Mazarías
 */
public class HiloServidor implements Runnable
{
	
	// socket donde estamos conectados
	private Socket elSocket;

	// stream para leer (recibir)
	private InputStream entrada;
	// stream para escribir (enviar)
	private OutputStream salida;


	//......................................................................
	//......................................................................
	public HiloServidor (Socket con) throws java.io.IOException
	{
                // guarda el socket (que me envía ServidorMultiHilo (en while true) )
		this.elSocket = con;

		// obtén streams para  entrada (recepción) y salida (envío)
		this.entrada = con.getInputStream();
		this.salida = con.getOutputStream();
                
		// crea un trhead para ejecute esta clase
		// y arráncalo
		
		Thread th = new Thread (this);
		th.start (); // ahora hay un nuevo thread en run()

	} // ()
	
	//......................................................................
	//......................................................................
	public void run ()
	{
            // COMPLETAR
            
            //.......1º Recibir la solicitud del cliente leyendo una línea de texto con ..........
            try{
            String linea=IO.leeLinea(this.entrada);
            //pasamos a comprobar si la linea es correcta
                        
            //.....2º Trocear (String.split()) la línea para sacar las palabras que contiene:
            
            String[] trozos = linea.split("[]+");
            
            //.... 3º Comprobar 
            //-que la línea de solicitud tiene al menos dos trozos. Si no,responder.
            if(trozos.length!=2)
            {
            IO.escribeLinea("HTTP/1.1 400 Bad Request: la solicitud no tiene 2 palabras", this.salida);
            IO.escribeLinea("", this.salida); // despues siempre se escribe una línea en blanco,
                                              //tal y como hemos acordado en el protocolo.
            // y terminar
           // salida.flush();
            this.entrada.close();
            this.salida.close();
            this.elSocket.close();
            return;
            }
            //-que la primera palabra de la solicitud es Get.Si no, responder "HTTP/1.1 400 bad request:
            // la solicitud no es get" y terminar
            if(trozos[0].equals("GET")==false)
            {
            IO.escribeLinea("HTTP/1.1 400 Bad REquest: la solicitud no es GET", this.salida);
            IO.escribeLinea("", this.salida);
            this.entrada.close();
            this.salida.close();
            this.elSocket.close();
            return;
            }
            //..... 4º Abrir el fichero pedido(segunda palabra de la solicitud)
            FileInputStream fich=new FileInputStream(trozos[1]);
            //para que el programa no acabe violentamente capturamos la excepcion
            try//Vamos a intentar abrir un fichero y nos puede dar error
            {
                fich=new FileInputStream(trozos[1]);//fichero en el que vamos a escribir
            }
            catch(FileNotFoundException ex)
            {
            IO.escribeLinea("HTTP/1.1 404 Not Found: no he encontrado el recurso", this.salida);
            IO.escribeLinea("", this.salida);
            this.entrada.close();
            this.salida.close();
            this.elSocket.close();
            return;
            }
            //A partir de aquí ya va todo bien
            //...... 5º Si hemos llegado hasta aquí ya podemos responder afirmativamente.
            // escribiremos las dos IO escribe línea, y línea en blanco y
            //copiaremos los bytes del flujo de entrada fich al de salida(vínculado al socket)
            IO.escribeLinea("HTTP/1.1 200 OK", this.salida);
            IO.escribeLinea("", this.salida);
            
            int numBytes=IO.copia(fich, this.salida);
            //copiamos el fichero en canal de salida
            
            // ya esta todo cerramos flujos y socket
            
            elSocket.close();
            entrada.close();
            salida.close();
            fich.close();            
            }//1ºtry
            catch(java.io.IOException ex)
            {
               Utilidades.muestraMensajeG("Error de conexión");
            }          
            
         } // ()
         public static int copia(InputStream entrada, OutputStream salida)throws IOException
            {
               int contador=0;
               int valorByte=entrada.read();
               //leemos el primer byte
               //esta función solo lee un byte
               
               /*¿Cómo se que he llegado al ultimo byte?habre llegado al final del
                * bucle de bytes, cuando llegue al byte -1 y supondremos que hemos
                * acabado*/
               while(valorByte!=-1)
                   /*tenemos que tener claro que los Strings se leen byte a byte,
                    * que no son un InputStream, el cual utilizamos para ficheros
                    * de texto*/
               {
                contador=contador+1;
                salida.write(valorByte);
                //escribimos en la salida(estaremos copiando)
                valorByte=entrada.read();
                //prepara la función para la siguiente lectura de byte
               }
               return contador;
            }// método de utilidad.
        
     

} // class
