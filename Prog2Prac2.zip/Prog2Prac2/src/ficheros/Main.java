
package ficheros;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import util.Utilidades;

//@autor Gema González Mazarías

public class Main {

	public static void main (String[] args) throws IOException {
            String nombreFicheroEscribir = Utilidades.leerTextoC("dime el nombre de un fichero para escribir");
                    
            
            FileWriter fE = new FileWriter(nombreFicheroEscribir);
            //creamos el fichero que hemos elegido antes
            
            PrintWriter salida = new PrintWriter(fE);
            String linea="Gema González Mazarías";
            salida.println(linea);//escribimos en el fichero nuestro nombre
            
            salida.close();//cerramos flujo
            fE.close();//cerramos flujo

	} // ()
} // class
