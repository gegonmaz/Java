package p1;

import java.util.ArrayList;

// Senyal como suma de funciones (nosotros utilizaremos
// senoidales)
public class Senyal
	implements Funcion
{
	private ArrayList<Senoidal> funciones; // funciones seno o coseno, indistintamente

	public Senyal (Senoidal f1, Senoidal ... lista ) {
		this.funciones = new ArrayList<Senoidal> ();

		this.funciones.add(f1);
		for (Senoidal f : lista) {
			funciones.add (f);
		} // for
	} // ()

	//
	// recibe un vector de cualquier cosa que sea (herede de) Senoidal
	public Senyal ( ArrayList<? extends Senoidal> lista)  {
		// me hago una  copia (en vez de asignar)
		this.funciones = new ArrayList<Senoidal> ();
		for (Senoidal f : lista) {
			funciones.add (f);
		} // for
	} // ()

	public double valor(double x) {
		// COMPLETAR
            double valorSuma=0.0;
            for(int i=0;i<=funciones.size()-1;i++)
            {
                valorSuma=valorSuma + funciones.get(i).valor(x);
                /*tenemos que ir sumando los valores de las funciones de la lista
                 * para ello, tenemos que coger lo que hay dentro de cada casilla
                 * de la lista y calcular su valor,y para ello utilizamos el 
                 * método valor() de la clase Senoidal, ya que las funciones son 
                 * Senos y Cosenos
                 */
            }
		return valorSuma;
	} //

	public Senoidal getFuncion (int n) {
		return funciones.get(n);
	} //

} // class
