
package p1;

/**
 *
 * @author 
 */
public interface Funcion {

	double valor (double x);

} // interface
