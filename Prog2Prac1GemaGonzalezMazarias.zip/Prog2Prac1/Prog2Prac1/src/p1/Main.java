
package p1;

//------------------------------------------------------------------------------

import java.io.IOException;
import java.util.ArrayList;

public class Main {
	public static final double DOS_PI = 2.0 * Math.PI;

	public static void main (String[] args) throws IOException {
		pruebaSenyal();
		pruebaMultiplicar();
		pruebaSintetizar();
		pruebaAnalizar();
	}

	public static void pruebaSenyal () throws IOException {
           Coseno c1= new Coseno(8.0,2.0);
           Coseno c2= new Coseno(4.0,10.0);
           Senyal s= new Senyal(c1,c2);
           
           double periodo= 2.0*Math.PI;//segundos
           double ts=periodo/100;//100 muestras en periodo
           Muestras m=Operaciones.tomarMuestras(s,0.0,periodo,ts);
           
           Utilidades.escribeEnNuevoFichero("senyal.dat",m.aTexto());
           Grafica graf1=new Grafica();
           graf1.dibuja(m,"prueba senyal");
	}

	public static void pruebaMultiplicar () throws IOException  {
            double periodo=2.0*Math.PI;//segundos
            double ts=periodo/100;//100 muestras en periodo
            
            Coseno c1=new Coseno(2.0,2.0);
            Coseno c2=new Coseno(1.0,5.0);
            
            Muestras m1=Operaciones.tomarMuestras(c1,0.0,periodo,ts);
            Muestras m2=Operaciones.tomarMuestras(c2,0.0,periodo,ts);
            Muestras m3=m1.multiplicar2(m2);
            
            Utilidades.escribeEnNuevoFichero("senyal.dat", m3.aTexto());            
            Grafica graf1=new Grafica();            
            graf1.dibuja(m3,"prueba multiplicar");
	}

	public static void pruebaSintetizar () throws IOException {
            ArrayList<Double> frec = new ArrayList<Double>();
            ArrayList<Double> ampl = new ArrayList<Double>();
                //creo los arrays de frecuencias y ampplitudes
            frec.add(1.0);
            frec.add(4.0);
            frec.add(5.0);

            ampl.add(4.0);
            ampl.add(2.0);
            ampl.add(1.0);
                //relleno los arrays
            FrecuenciasAmplitudes fa = new FrecuenciasAmplitudes(frec, ampl);
            Senyal s = Operaciones.sintetizarSenyal(fa);
            //no declaramos un objeto para llamar al método porque es estático
            //y no consulta nada de su interior
            double periodo = 2.0 * Math.PI;//segundos
            double ts = periodo / 100.0;//100 muestras en el periodo
            Muestras m = Operaciones.tomarMuestras(s, 0.0, periodo, ts);
            Grafica graf1 = new Grafica();
            graf1.dibuja(m, "Prueba Sintetizar");
	} // main ()

	public static void pruebaAnalizar () throws IOException {
            Coseno c1=new Coseno(8.0,3.0);
            Coseno c2=new Coseno(4.0,5.0); 
            Coseno c3=new Coseno(3.0,8.0);
            Coseno c4=new Coseno(7.0,10.0); 
            Senyal y=new Senyal(c1,c2,c3,c4);
            
            double periodo=2.0*Math.PI;//segundos
            double ts=periodo/100.0;//100 muestras en el periodo
            Muestras my=Operaciones.tomarMuestras(y, 0.0, periodo, ts);
            
            Utilidades.escribeEnNuevoFichero("senyal.dat", my.aTexto());
            Grafica g1=new Grafica();
            g1.dibuja(my,"Prueba Analizar:Senyal Original");
            //...........................................................
           
            FrecuenciasAmplitudes fa=Operaciones.analizarMuestras(my);
            Grafica g2=new Grafica();
            g2.dibuja(fa.comoMuestras(),"Prueba Analizar:Frec-Ampl");
            //porque tenemos que convertir el objeto
            //frecuenciasamplitudes en muestras
            Senyal s=Operaciones.sintetizarSenyal(fa);
            Muestras ms=Operaciones.tomarMuestras(s, 0.0, periodo, ts);
            Grafica g3=new Grafica();
            g3.dibuja(ms,"Prueba Analizar: Señal sintetizada");
            
	} // ()

} // class
