
package p1;

import java.util.ArrayList;

/**
 *
 * @author nadie
 */
public class Operaciones {

	//.........................................................................
	//.........................................................................
	public static Muestras tomarMuestras (Funcion f, double xMin, double xMax, double delta) {

		ArrayList<Double> indices = new ArrayList<Double> ();
		ArrayList<Double> muestras = new ArrayList<Double> ();

		for (double x=xMin; x<=xMax; x=x+delta) {
			indices.add(x);
			muestras.add ( f.valor(x));
		}

		Muestras res = new Muestras (indices, muestras);

		return res;
	} // ()

	//.........................................................................
	//.........................................................................
	public static double integral (Funcion f, double xMin, double xMax, double delta) {

		Muestras m = tomarMuestras (f, xMin, xMax, delta);

		return Operaciones.integral(m);
	} // ()

	//.........................................................................
	//.........................................................................
	public static double integral (Muestras m) {
		// COMPLETAR
            double sum=0.0;
            for(int i=1;i<=m.talla()-1;i++)
            {
                double base= m.indice(i)-m.indice(i-1);
                sum=sum+(m.muestra(i)*base);
            }
		return sum;
	} // ()

	//.........................................................................
	// creamos un objeto senyal como sumatorio de cosenos
	// con las frecuencias y amplitudes recibidas
	//.........................................................................
	public static Senyal sintetizarSenyal (FrecuenciasAmplitudes fa) {
		// COMPLETAR
            ArrayList<Coseno> cosenos=new ArrayList<Coseno>();
            double a;
            double f; 
            Coseno cos;
            
            for(int i=0;i<=fa.talla()-1;i++)
            {
                a=fa.getAmplitudEn(i);
                f=fa.getFrecuenciaEn(i);
                cos=new Coseno(a,f);
                cosenos.add(cos);
            }
            Senyal s=new Senyal(cosenos);
            return s;		
	} // ()

	//.........................................................................
	//.........................................................................
	public static FrecuenciasAmplitudes analizarMuestras (Muestras m) {
		// COMPLETAR
            ArrayList<Double>vFrec=new ArrayList<Double>();
            ArrayList<Double>vAmpl=new ArrayList<Double>();
            double T=m.periodo();
            double ts=m.indice(1)-m.indice(0);//averiguamos el intervalo de muestreo
            
            for(double k=0;k<=m.talla()/2;k++)
            {
                vFrec.add(k);
                Coseno cos=new Coseno (1.0,k);
                
                Muestras mc=Operaciones.tomarMuestras(cos, 0.0, T, ts);
                Muestras mp=m.multiplicar2(mc);
                
                double a=(2/T)*Operaciones.integral(mp);
                vAmpl.add(a);                
            }
            return (new FrecuenciasAmplitudes(vFrec,vAmpl));
	} // ()

} //
