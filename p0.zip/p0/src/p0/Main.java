/**
 *
 * @author Gema González Mazarías
 */

package p0;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        
        System.out.println("Hola mundo");
        //escribir directamente en consola Hola mundo
        //...
	String linea = JOptionPane.showInputDialog("Escribe algo");
        //escribir en la ventana de entrada

	JOptionPane.showMessageDialog(null, "has escrito " + linea);
        //mostrar en la ventana de salida lo que hemos escrito en la ventana 
        //de entrada
        
        System.out.println(linea);
        //escribimos en consola lo que hemos introducido en la ventana de entrada 
        
        //....................................................................
        
        int a;
        a=10;
        a=a - 1;
        a=a/2;
        
        JOptionPane.showMessageDialog(null, "a vale " + a);
        
        //....................................................................
        
        double b;
        b=10;
        b=b-1;
        b=b/2;
        
        JOptionPane.showMessageDialog(null, "b vale " + b);
        
        //....................................................................
       
       
        
        
        

    } // ()

} // class
