package p4;
import java.util.ArrayList;
//--------------------------Gema González Mazarías------------------------------
//------------------------------------------------------------------------------
public class Polinomio
	implements Funcion {
	private ArrayList<Double> coeficientes;
	//.........................................................................
	public Polinomio() {                                
		coeficientes = new ArrayList<Double>();
		coeficientes.add(0.0);
                /*tenemos que asegurarnos de que al crear el Polinomio(new),este
                  tenga algún elemento */
	} // ()
	//.........................................................................
	public Polinomio(String texto) {
		coeficientes = Utilidades.textoAArrayListDouble(texto);
		if (coeficientes.isEmpty()) {
			// por si del texto no se hubiera sacado
			// ningun coeficiente
			coeficientes.add(0.0);
                }
	} // ()
	//.........................................................................
	public String aTexto() {
		StringBuilder texto = new StringBuilder();
		for (double v : coeficientes) {
			texto.append(" ").append(v);
		}
		return texto.toString();
	} // ()
	//.........................................................................
	public double valor(double x) {
		//return 0.0; // COMPLETAR            
            double v=0.0;
            double c;
            for(int i=0;i<=coeficientes.size()-1;i++)
            {                
                c=coeficientes.get(i);
                v=v+c*(Math.pow(x,i));       
            }
            return v;
	}
	//.......................COMPLETAR el resto de la clase.................	  
	//......................................................................
        public int grado()
        {
            return coeficientes.size()-1;          
        }
        //----------------------------------------------------------------------
        public double coeficiente(int i)
        {
           /* return coeficientes.get(i);--> esto seria lo mejor,pero que pasa
           si el grado es negativo o no existe */
            if((i<0)||(i>grado()))
            {
                return 0.0;/*Devolvemos 0,por si tuviesemos que hacer alguna operacion,
                             no nos causara ninguna alteracion */
            } 
            
            else
            {
                return coeficientes.get(i);
            }
        }
        //----------------------------------------------------------------------
        public Polinomio multiplicar(double r)
        {
            Polinomio m=new Polinomio();
            m.coeficientes.clear();
            double co;
            for(int i=0;i<=this.grado();i++)
            {//si se quisiera complicar la cosa:Si el Polinomio es 0,modificarlo
             //[
              /*if(i==0)
                {
                    m.coeficientes.set(0,this.coeficientes.get(i)*r);
                }
                else
                { //]*/
                co=coeficientes.get(i)*r;
                m.coeficientes.add(co);
               // }
            }
            return m;      
        }
        //----------------------------------------------------------------------
        public Polinomio suma(Polinomio x)
        {
            Polinomio s=new Polinomio();
            s.coeficientes.clear();
            double co=0.0;
           /* for(int i=0;i<=coeficientes.size()-1;i++)
            {
                co=this.coeficientes.get(i)+x.coeficientes.get(i);
                s.coeficientes.add(co);
            }            
            return s; *///estaria bien si los Polinomios fuesen del mismo grado
            if(this.grado()<x.grado())
            {
                for(int i=0;i<=this.grado();i++)
                {
                    s.coeficientes.add(this.coeficientes.get(i)+x.coeficientes.get(i));
                }                           //grado del mayor
                for(int j=this.grado()+1;j<=x.grado();j++)
                {           //dnd me he quedado sumando(grado()+1)
                    s.coeficientes.add(x.coeficientes.get(j));
                }
            }
            else
            {
                for(int i=0;i<=x.grado();i++)
                {
                    s.coeficientes.add(x.coeficientes.get(i)+this.coeficientes.get(i));
                }                           //grado del mayor
                for(int j=x.grado()+1;j<=this.grado();j++)
                {           //dnd me he quedado sumando(grado()+1)
                    s.coeficientes.add(this.coeficientes.get(j));
                }                
            }
            return s;
        }
        //----------------------------------------------------------------------
        //------------------Multiplicacion de polinomios------------------------
        public Polinomio Multiplicar(Polinomio p)
        {
            int grado=this.grado()+this.grado();
            Polinomio res=new Polinomio();
            //aqui ya tenemos creada un acasilla 0 con valor 0
            for(int i=1;i<=grado-1;i++)
                //g-1;porque ya tenemos creada una casilla
            {
                res.coeficientes.add(0.0);
                /*añado las casillas del polinomio final con todo 0.0,asi solo 
               tendre que irle sumando los resultados que me vayan dando */
            }
            for(int j=0;j<=this.grado();j++)
            {
                for(int k=0;k<=p.grado();k++)
                {
                res.coeficientes.set(j+k,res.coeficiente(j+k)+this.coeficiente(j)*p.coeficiente(k));
                /*Cojo la casiila j+k(grado) y a lo que tiene le añado el resultado
                 * de multiplicar los coeficientes*/
                }
            }
            return res;
        }
        //----------------------------------------------------------------------
        public Polinomio derivar()
        {
            Polinomio res=new Polinomio();
            /*tenemos la casilla 0 con valor 0 creada,con lo cual todos los polinomios
             * de grado 0 ya estan derivados*/
            if(this.grado()>0)
            {
                res.coeficientes.clear();
                /*vaciamos el array res que tiene cas 0,y asi nos coincidiran 
                 las casillas del polinomio res*/
                for(int i=1;i<=this.grado();i++)
                {
                    res.coeficientes.add(this.coeficiente(i)*i);
                }
            }
            return res;
        }
        //----------------------------------------------------------------------
        public double derivadaDefinida(double a)
        {            
            Polinomio res=new Polinomio();
            /*tenemos la casilla 0 con valor 0 creada,con lo cual todos los polinomios
             * de grado 0 ya estan derivados*/
            if(this.grado()>0)
            {
                res.coeficientes.clear();
                /*vaciamos el array res que tiene cas 0,y asi nos coincidiran 
                 las casillas del polinomio res*/
                for(int i=1;i<=this.grado();i++)
                {
                    res.coeficientes.add(this.coeficiente(i)*i);
                    
                }
            }
            double x=res.valor(a);
            return x;
        }
        //----------------------------------------------------------------------
        public Polinomio integral()
        {
            Polinomio res=new Polinomio();
            for(int i=0;i<=grado();i++)
            {
                res.coeficientes.add(this.coeficiente(i)/(i+1));                
            }
            return res;
        }
        
        //----------------------------------------------------------------------
        public double integralDefinida(double a,double b)
        {//lo implementamos desde cero
            Polinomio res=new Polinomio();
            for(int i=0;i<=grado();i++)
            {
               res.coeficientes.add(this.coeficiente(i)/(i+1)); 
            }
            double r=res.valor(b)-res.valor(a);
            return r;
        }
        //----------------------------------------------------------------------
        public double integralDefinida2(double a,double b)
        {//llamando al metodo integral
           Polinomio p=new Polinomio();
           double r=p.valor(b)-p.valor(a);
           return r;
        }
        //------------------ejercicios sobre practica---------------------------
        public boolean gradoMayor(Polinomio p)
        {
            if(this.grado()>p.grado())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //----------------------------------------------------------------------
         public boolean gradoIgual(Polinomio p)
        {
            if(this.grado()==p.grado())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
         //---------------------------------------------------------------------
         public Polinomio copia()
         {
             Polinomio copia=new Polinomio();
             copia.coeficientes.clear();
             for(int i=0;i<=this.grado();i++)
             {
                 copia.coeficientes.add(coeficiente(i));
             }
             return copia;             
         }
         //---------------------------------------------------------------------
         public int cuantosIguales(double r)
         {
             int c=0;
             for(int i=0;i<=this.grado();i++)
             {
                if(r==coeficiente(i))
                {
                    c++;
                }
             }
             return c;
         }
        
} // class Polinomio

