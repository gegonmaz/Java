package p4;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Jordi
 */
public class Grafica
	extends JFrame {

	private Canvas lienzo;
	private Muestras losDatos = null;

	public Grafica() {
		super.setTitle("Gráfica");
		super.setBounds(30, 30, 800, 600);

		// -----------------------------------------------------------------
		lienzo = new Canvas() {

			private Rectangle marc;
			private double anchoDatos;
			private double altoDatos;
			private int separacion = 10;

			@Override
			public void paint(Graphics g) {

				marc = new Rectangle(separacion, separacion, super.getWidth() - 2 * separacion, super.getHeight() - 2 * separacion);

				g.setColor(Color.RED);
				g.drawRect(marc.x, marc.y, marc.width, marc.height);

				if (losDatos == null) {
					// System.err.println (" nada que pintar ");
					return;
				}

				anchoDatos = losDatos.maxX() - losDatos.minX();
				altoDatos = losDatos.maxY() - losDatos.minY();

				int c1;
				int f1;
				int c2;
				int f2;

				g.setColor(Color.BLUE);

				c1 = xAc(losDatos.indice(0));
				f1 = yAf(losDatos.muestra(0));
				for (int i = 1; i <= losDatos.talla() - 1; i++) {


					c2 = xAc(losDatos.indice(i));
					f2 = yAf(losDatos.muestra(i));

					g.setColor(Color.BLUE); // muestra
					g.fillRect(c1 - 3, f1 - 3, 6, 6);

					g.setColor(Color.LIGHT_GRAY); // altura muestra
					g.drawLine(c1, f1, c1, yAf(0));

					g.setColor(Color.MAGENTA); // linea continua
					g.drawLine(c1, f1, c2, f2);
					c1 = c2;
					f1 = f2;

				} // for

				// la ultima muestra y su altura
				g.setColor(Color.BLUE);
				g.fillRect(c1 - 3, f1 - 3, 6, 6);
				g.setColor(Color.GRAY); // altura muestra
				g.drawLine(c1, f1, c1, yAf(0));

				// eje Y=0
				g.setColor(Color.BLACK);
				g.drawLine(marc.x, yAf(0), marc.width + marc.x, yAf(0)); // eje X en y==0
			} // paint

			private int xAc(double x) {
				return (int) Math.floor(marc.width * (x - losDatos.minX()) / (anchoDatos)) + separacion;

			}

			private int yAf(double y) {
				// para que este a la misma escala ejes X e Y
				// pero a lo mejor algunos puntos no se ven por que "se salen"
				return (int) Math.floor(marc.height * (losDatos.maxY() - y) / (altoDatos)) + separacion;

			}
		}; // new Canvas
		// -----------------------------------------------------------------

		super.add(lienzo);

		super.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				((JFrame) e.getSource()).dispose();
				System.exit(0);
			}
		});

		super.setVisible(true);
	} // constructor Grafica ()

	public synchronized void dibuja(Muestras datos) {
		this.losDatos = datos;
		// this.repaint();
		this.lienzo.repaint();
	}
} // class

