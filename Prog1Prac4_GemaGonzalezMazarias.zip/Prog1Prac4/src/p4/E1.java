package p4;

//------------------------------------------------------------------------------
public class E1 {

	//.........................................................................
	//.........................................................................
	public static void main(String[] args) {
		pruebasPolinomio();
		pruebasIntegral();
		pruebasGrafica();
	} // ()

	//.........................................................................
	//.........................................................................
	public static void pruebasPolinomio() {

		// pruebas de la clase polinomio
		Polinomio p1 = new Polinomio("1 2 3 4");
                System.out.println("El p1 es:" + p1.aTexto());
                Polinomio p2=new Polinomio();
                Polinomio p3=new Polinomio("2.0 3.5 4.0 6.0 7.0");
                double v1=p1.valor(6.0);//prueba valor
                System.out.println("El valor del polinomio con x=6 es: " + v1);
                int g1=p3.grado();//prueba grado
                System.out.println("el grado del polinomio 3 es: " + g1);
                Polinomio p4=p1.multiplicar(5.0);//prueba multiplicar
                System.out.println("p4 es: " + p4.aTexto());
                p2=p1.suma(p3);//prueba suma
                System.out.println("El p2 es: " + p2.aTexto());
                double c1=p2.coeficiente(3);//prueba coeficiente
                System.out.println("El coeficiente del p2 en grado 3 es: " + c1);
                double c2=p1.coeficiente(2);
                System.out.println("El coeficiente del p1 en grado 2 es: " + c2);                
	} // ()

	//.........................................................................
	//.........................................................................
	   public static void pruebasIntegral() {
        // pruebas del calculo de la integral
             double xMin = 0;
             double xMax = 1;
             double delta = 0.000001;//No hay que poner muchos 0;porque da error
             Polinomio p1 = new Polinomio("3");
             double integral1 = Operaciones.integral(p1, xMin, xMax, delta);
             System.out.println("La integral en [0,1] de f(x)=3 es: " + integral1);
             Polinomio p2 = new Polinomio("0 1");
             double integral2 = Operaciones.integral(p2, xMin, xMax, delta);
             System.out.println("La integral en [0,1] de f(x)=x es: " + integral2);
             Polinomio p3 = new Polinomio("0 0 1");
             double integral3 = Operaciones.integral(p3, xMin, xMax, delta);
             System.out.println("La integral en [0,1] de f(x)=x^2 es: " + integral3);
    } // ()

	//.........................................................................
	//.........................................................................
	public static void pruebasGrafica() {
		// pruebas para el dibujo de gráficas
		// Ahora mismo no se ve nada porque
		// el método Polinomio.valor() y Operaciones.tomarMuestras()
		// no están bien implementados
		Polinomio p1 = new Polinomio("0 0 0.1 -1.2 0.1"); // x^4
		Grafica graf = new Grafica();
		Muestras m = Operaciones.tomarMuestras(p1, -10.0, 10.0, 0.1);
		graf.dibuja(m);
	} // ()
} // class
