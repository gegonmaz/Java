package p4;
import java.util.ArrayList;
//Gema González Mazarías
public class Muestras {
	private ArrayList<Double> losIndices; // x
	private ArrayList<Double> lasMuestras; // y = f(x)
	private double muestraMenor; // para no buscarla cada vez
	private double muestraMayor; // para no buscarla cada vez
	//.........................................................................
	public Muestras (ArrayList<Double> indices, ArrayList<Double> muestras) {
		// el tamaño ha de ser el mismo
		if ( indices.size() !=  muestras.size() ) {
			throw new Error ("indices y muestras son de distinto tamaño");
		}
		double a = indices.get(0);
		for (double b : indices) {
			if (a > b) {
				throw new Error ("los indices no estan ordenados de menor a mayor");
			}
			a = b;
		} // for
		// todo correcto:
		losIndices = indices;
		lasMuestras = muestras;
		// busco ahora la menor y la mayor muestra y las guardo
		muestraMenor = java.util.Collections.min(lasMuestras);
		muestraMayor = java.util.Collections.max(lasMuestras);
	} // ()
	//.........................................................................
	public double indice(int i) {
		return losIndices.get(i);
	}
	//.........................................................................
	public double muestra(int i) {
		return lasMuestras.get(i);
	}
	//.........................................................................
	public int talla () {
		return losIndices.size();
	}
	//.........................................................................
	public double minX () {
            //asumimos que los losIndices estan ordenados <
		return losIndices.get(0);
	}
	//.........................................................................
	public double maxX () {
            // asumimos que los losIndices estan ordenados <
		return losIndices.get(losIndices.size()-1);
	}
	//.........................................................................
	public double minY () {
		return muestraMenor;
	}
	//.........................................................................
	public double maxY () {
		return muestraMayor;
	}
} // class