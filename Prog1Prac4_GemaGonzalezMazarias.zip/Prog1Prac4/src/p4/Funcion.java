
package p4;

public interface Funcion {

	double valor (double x);

} // interface
