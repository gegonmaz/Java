package p4;
import java.util.ArrayList;
//Gema González Mazarías
public class Operaciones {
	//.........................................................................
	//.........................................................................
	public static Muestras tomarMuestras (Funcion f, double xMin, double xMax, double delta) 
        {
           ArrayList<Double> indices= new ArrayList<Double>();
           ArrayList<Double> valores=new ArrayList<Double>();
           for(double x=xMin;x<xMax;x=x+delta)
           {
               indices.add(x);//no hay que igualar a nada para añadir en un array.
               valores.add(f.valor(x));
           }		
           Muestras muestras=new Muestras(indices,valores);
           return muestras;
	} // ()
	//.........................................................................
	//.........................................................................
	public static double integral (Funcion f, double xMin, double xMax, double delta) 
        {
            Muestras muestras=tomarMuestras(f,xMin,xMax,delta);
            double sum=0.0;
            for(int i=0;i<muestras.talla();i++)
            {/*no sabemos cuantaas muestras hay,por tanto utilizaremos el metodo 
               talla de la clase Muestras*/ 
                
                /*tenemos que acceder a lasMuestras de la clase Muestras;pero no
                 * podemos acceder directmente a la parte privada de una clase 
                 * desde otra clase,por tanto utilizamos el metodo muestra,que se
                 * encarga de acceder a lasMuestras de la clase*/
                sum=sum + Math.abs(muestras.muestra(i));
                /*Para calcular la integral por el metodo de barrow,tenemos que
                 * calcular las areas en valor absoluto,ya que sino podriamos
                 * anular unas con otras,teniendo en cuenta que se irian sumando
                 * y restando*/               
            }
            double resultado=sum*delta;		
            return resultado;
	} // ()
        //-----------------Segun algoritmo prac---------------------------------
        public static double integral2 (Funcion f, double xMin, double xMax, double delta) 
        {
            Muestras muestras=tomarMuestras(f,xMin,xMax,delta);
            double sum=0.0;
            for(int i=0;i<muestras.talla();i++)
            {
                sum=sum + muestras.muestra(i);                           
            }
            double resultado=sum*delta;		
            return resultado;
	} // ()
        //----------------------------------------------------------------------
        //pero entonces ese calculo no estaria bien hecho,porque se nos iria anulando,
        //por lo que tendriamos que calcular ahora el area(es decir hacer integral
        //en dos paso:integral2 y area)
        public static double area (Funcion f, double xMin, double xMax, double delta)
        {
            double a=Operaciones.integral(f,xMin,xMax,delta);
            /*cuando llamamos a un metodo estatico,tenemos que llamar a la clase
             * a la que perteece el metodo,ya uqe esta carece de estructura interna
               es como utilizar la clase Utilidades o Math */
            return a;
        }
} //
