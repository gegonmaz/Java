package p4;

import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.ArrayList;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
public class Utilidades {

	//.........................................................................
	//.........................................................................
	public static int leerEntero (String mensaje) {

		int v = Integer.parseInt( JOptionPane.showInputDialog(mensaje) );

		return v;
	} // ()

	//.........................................................................
	//.........................................................................
	public static double leerReal (String mensaje) {

		return  Double.parseDouble( JOptionPane.showInputDialog(mensaje) );
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraMensaje (String mensaje) {

		JOptionPane.showMessageDialog(null, mensaje);
	} // ()

	//.........................................................................
	//.........................................................................
	public static double[] leerArrayDeReales (String mensaje) {

		// leo un texto
		String loLeido = JOptionPane.showInputDialog(mensaje) ;

		// la siguiente funcion hace la transformacion
		return textoAArrayDouble(loLeido);

	} // ()

	//.........................................................................
	//.........................................................................
	public static double[] textoAArrayDouble (String texto) {

		// de texto paso a vector de double
		ArrayList<Double> almacen = textoAArrayListDouble(texto);

		// de vector de double paso a array de double
		// (los copio del vector al array resultado)
		double[] resultado = new double[almacen.size()];

		for (int i=0; i<=resultado.length-1; i++) {
			resultado[i] = almacen.get(i);
		}

		return resultado;
	} // ()

	//.........................................................................
	//.........................................................................
	public static ArrayList<Double> textoAArrayListDouble (String texto) {

		// el Scanner me sacara los numeros de uno en uno con .nextDouble()
		// el separador enteros/decimanes sera el punto (como en US)
		Scanner troceador = new Scanner (texto).useLocale(java.util.Locale.US);

		ArrayList<Double> resultado = new ArrayList<Double> ();

		double x;

		// saco los numeros del string, mientras haya
		while ( troceador.hasNextDouble() ) {
			x = troceador.nextDouble();
			resultado.add(x);
		}

		return resultado;
	} // ()

	//.........................................................................
	//.........................................................................
	public static void muestraArrayList (String mensaje, ArrayList<?> vec) {

		StringBuilder texto = new StringBuilder (mensaje + "\n");

		for (Object o : vec) {
			texto.append(o).append(", ");
		}

		System.out.println (texto);

		JOptionPane.showMessageDialog(null, texto.toString());
	} // ()

} // class Utilidades
