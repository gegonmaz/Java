/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.servidor;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Gema
 */
public class ServidorMiniChat 
{
    private static final GestorParticipantes elGestor= new GestorParticipantes();
    
    public static void main(String[] args)throws java.io.IOException 
                                           //para cualquier error que pueda surgir
    {
        int PUERTO =1234;
        
        System.out.println("*****************************************************");
        System.out.println("Para contactar conmigo: ");
        System.out.println ("\n       "+InetAddress.getLocalHost().getHostAddress() +" " + PUERTO);
	System.out.println ("       "+InetAddress.getLocalHost().getHostName() +" " + PUERTO);
	System.out.println("*****************************************************");
        
        ServerSocket ss= new ServerSocket(PUERTO); 
        while(true)
        {
            Socket s =ss.accept();
            new ParticipanteProxy(s,elGestor);  
        }        
    }
}
