/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.servidor;


import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Gema
 */
public class GestorParticipantes 
{
    
    private ArrayList<ParticipanteProxy> losParticipantes;
    public GestorParticipantes() 
    {
        //inicializamos estructura interna
        this.losParticipantes = new ArrayList<ParticipanteProxy> ();
    }
   private synchronized ParticipanteProxy buscaParticipante(String Nick){
       /*
        * Como al Gestor acceden procesos,estan compartiendo la misma variable
        * (la lista de participantes),por tanto se pueden dar condiciones de 
        * carrera,como que se este dando de baja un participante,mientras se
        * esta añadiendo a otro participante.Por tanto tengo que garantizar el 
        * trabajo del proceso(SYNCHRONIZED)
        */
        //recorremos el array de participantes y miramos a ver si el nick con el
        //cual queremos conectarnos se encuentra disponible
       for(ParticipanteProxy p:this.losParticipantes){
           if(p.getNick().equals(Nick)==true){
               return p;
           }
       }//si no encuentra al participante,acaba
        return null;
    }
    
    public synchronized boolean estaConectado(String nick){
        
        if(buscaParticipante(nick)==null){
            return false;
        }
        return true;
    }
    
    public synchronized String anyadeParticipante(ParticipanteProxy p)throws NickEnUsoException
    {
        //provocamos una excepcion(throws NickEnUsoException)
        //UNA FUNCION CUALQUIERA ES CAPAZ DE LANZAR UNA ALARMA EN EL SISTEMA
        if(!estaConectado(p.getNick())){
            this.losParticipantes.add(p);
        }
        else{
            NickEnUsoException ex=new NickEnUsoException("Nick existente: " + p.getNick());
            throw ex;//lanzo la excepcion
        }
        return listaParticipantes();
    }
    
    public synchronized void eliminarParticipante(ParticipanteProxy p)
    {
        if(estaConectado(p.getNick())==true)
        {
            this.losParticipantes.remove(p);               
        }      
    }
    
    /*
     * -------------------------ECHAR PARTICIPANTE------------------------------
     */
      public synchronized void echarParticipante(String nick) throws IOException
      {
          ParticipanteProxy p=buscaParticipante(nick);
          if(p!=null)
           {
               p.cerrar(nick + "Has sido eliminado");   
               difundeMensaje(listaParticipantes());
          }
      }
     
    
    public synchronized void difundeMensaje(String s) throws IOException
    {
        for(ParticipanteProxy p:this.losParticipantes){
            p.entregaMensaje(s);
        }        
    }
    
    /*
     * ----------------SI YO NO QUIERO RECIBIR MI PROPIO MENSAJE----------------
     */ 
      public synchronized void difundeMensaje(String s,String nick) throws IOException
      {
           for(ParticipanteProxy p:this.losParticipantes)
           {
               if(p.getNick().equals(nick)==false)
               {
                   p.entregaMensaje(s);
               }
           }
      }   
    
    /*
     * ---------------------PARA ENVIAR UN MENSAJE PRIVADO----------------------
     */ 
      public synchronized void MensajePrivado(String msj,String nick) throws IOException
      {
           for(ParticipanteProxy p:this.losParticipantes)
           {
               if(p.getNick().equals(nick)==true)
                   {
                       p.entregaMensaje(msj);
                   }
           }
      }
     
    
    public synchronized String listaParticipantes(){
        StringBuilder sb = new StringBuilder();
        for(ParticipanteProxy p : this.losParticipantes){
            sb.append(p.getNick()).append("");
            
        }
        return sb.toString();
    }    
    
    //----------------------------ADAPTACION TWITTER---------------------------//
    synchronized public void DifundeTwitter(String msj,String nickEmisor) throws IOException
    {
        for(ParticipanteProxy p:this.losParticipantes)
        {
            if(p.seguirA(nickEmisor)==true)
            {
                p.entregaMensaje(msj);
            }
        }
    }
}//class

