/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.servidor;

/**
 *
 * @author Gema
 */
public class NickEnUsoException extends Exception
{
    //el problema de hacer una excepcion,esque derive de la clase Exception

    private String mensaje;
    public NickEnUsoException(String mensajeX)
    {
        try
        {
           this.mensaje=mensajeX;
           //super(mensaje);//para saber cual es el mensaje(OPCIONAL)
        }
        catch(Exception ex)
        {
            ex.getMessage();//para saber cual es el mensaje que ha puesto el S.O
        }
    }   
}
