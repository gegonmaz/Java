/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.servidor;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import util.Utilidades;

/**
 *
 * @author Gema
 */
public class ParticipanteProxy implements Runnable
{
    private Socket elSocket;
    private GestorParticipantes elGestor;
    private InputStream entrada;
    private OutputStream salida;
    private String nick;  //participante(cliente) al que representa
    private boolean seguir;
    
    public ParticipanteProxy(Socket con,GestorParticipantes ges) throws IOException
    {
        try
        {
            this.elSocket=con;
            this.elGestor=ges;
            this.seguir=true;
            //asignamos la entrada y la salida al socket(via de comunicación)
            //para poder enviar y recibir
            this.entrada=this.elSocket.getInputStream();
            this.salida=this.elSocket.getOutputStream();
            this.nick=recibeMensaje();
            try//por si el nick que se va a utilizar ya está en uso
            {
                this.elGestor.anyadeParticipante(this);//me añado a mi mismo                
            }
            catch(NickEnUsoException ex)
            {
                //solo enviamos mensaje al participante que intenta conectarse
                 entregaMensaje("el nick ya existe");
                 cerrar(null);//no esty conectado ahun,asi que no envio mensaje
                 return;
            }
            
            //SI NO HAY EXCEPCION
            entregaMensaje("OK");
            Thread th=new Thread(this);
            th.start();//empezamos a ejecutr el proceso del run
            //estoy utilizando funciones de comunicacion,por ello todo lo meteremos
            //en un try por si surge algun error en la comunicacion.
        }//try
        catch(IOException e)
        {
              cerrar ("Se retira del chat " + this.nick);      
        }
    }//()
    
     public String getNick()
    {
        return this.nick;//porque elGestor va a tener que saber cual es el nick 
                         //para utilizarlo
    }//()
    
    
    public void run()
    {
        try
        {
        this.elGestor.difundeMensaje("Se conecta " + this.nick);
        this.elGestor.difundeMensaje(this.elGestor.listaParticipantes());
        while(this.seguir==true)
        {
            String mensaje=recibeMensaje();            
            String [] trozos=mensaje.split("[ ] + ");
            
            
     //--------------COMPROBAR SI YO QUIERO ECHAR A ALGUIEN-----------------//
     
            if(trozos[0].equals("ECHAR"))
            {
                 this.elGestor.echarParticipante(trozos[1]);
            }
            /*
             * Segun el protocolo establecido si alguno de los participantes del
             * chat envia la palabra SALIR,automaticamente saldra de la conversa-
             * cion y se le avisara al resto de participantes.
             */
            if(mensaje.equals("SALIR")==true)
                //si algun participante escribe SALIR,saldria de la conversacion
                //por tanto hay que comprobar que no sea SALIR
            {
                cerrar("Se retira de la conversacion: " + this.nick);
                return;
            }
            else
            {
                mensaje=this.nick + ":" + mensaje;
                this.elGestor.difundeMensaje(mensaje);
            }
        }
        cerrar(null);
        }
        catch(IOException ex)
        {
            Utilidades.muestraMensajeG("Se ha producido un ERROR al conectarse");
        }
    }//()
    
        
    public void entregaMensaje(String mensaje) throws IOException
    {
        if (mensaje == null || mensaje.length() == 0)
        {
            return;
        }
        try 
        {
            IO.escribeLinea(mensaje, this.salida);
        }   
        catch (IOException ex) 
        {
            this.cerrar("chat> se retira por fallos en la conexión (entregaMensaje()): " + this.nick);
        }
    }//()
    
    
    private String recibeMensaje() throws IOException 
    {
        try 
        {
            return IO.leeLinea(this.entrada);
        } 
        catch (IOException ex)  
        {
            this.cerrar("chat> se retira por fallos en la conexión (recibeMensaje()): " + this.nick);
        }
        return "";
    } // ()
    
    
     public void cerrar(String mensaje) throws IOException 
     {
       this.seguir=false;
       this.elGestor.eliminarParticipante(this);
       this.entrada.close();
       this.salida.close();
       this.elSocket.close();
       if((mensaje!=null)&&(mensaje.length()!=0)){
           this.elGestor.difundeMensaje(mensaje);
           this.elGestor.difundeMensaje(this.elGestor.listaParticipantes());
      }
    }
     
     //------------------------ADAPATCION TWITTER------------------------------//
     
     private ArrayList<String> seguidos=new ArrayList<String>();
     
     public boolean seguirA(String nick)
     {
         for(String s:this.seguidos)
         {
             if(s.equals(nick)==true)
             {
                 return true;
             }             
         }
         return false;
     }
}//class
