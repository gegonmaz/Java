/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.participante;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import util.IO;
import util.Utilidades;

/**
 *
 * @author Gema
 */
public class Participante {
    
    private static Socket elSocket;
    private static String hostServidor;
    private static int PUERTO;
    private static InputStream entrada;
    private static OutputStream salida;
    private static String nick;
    private static Escuchador miEscuchador;//para poder recibir los mensajes
                                           //necesito otro proceso
    
    //donde esta el servidor y en que puerto
    private static void obtenerIpPuerto()
    {
        try{
            String linea=Utilidades.leerTextoG("Dime direccion de Servidor (Ip:Puerto)");
            //troceamos la linea donde encontramos IP y Puerto
            String[] trozos=linea.split(":");//dividimos el string por los puntos
            
            //consideramos que si al trocear no hay dos palabras dara ERROR
            if(trozos.length !=2)
            {
                Utilidades.muestraMensajeG("No ha tenido exito la conexion");
                acabar();                
            }
            else
            {    
            hostServidor=trozos[0];
            PUERTO=Integer.parseInt(trozos[1]);//convertimos string a entero            
            }
        }//try
        catch(Exception ex)
        {
            Utilidades.muestraMensajeG("ERROR obteniendo IP PUERTO");
            acabar();
        }
    }//()
    
    //abriremos la conexion creando un socket
    private static void abrirConexion()
    {
        try{
            //podemos llamarlo desde la clase
            
            /*Participante.elSocket=new Socket(Participante.hostServidor,Participante.PUERTO);
            Participante.entrada=Participante.elSocket.getInputStream();
            Participante.salida=Participante.elSocket.getOutputStream();*/
            
            elSocket=new Socket(hostServidor,PUERTO);
            entrada=elSocket.getInputStream();
            salida=elSocket.getOutputStream();
        }
        catch(IOException ex)
        {
            Utilidades.muestraMensajeG("ERROR abriendo conexion");
            acabar();
        }
    }//()
    
    //preguntamos al usuario su nick
    private static void iniciarSesion()
    {
        String confirmacion;
        Participante.nick=Utilidades.leerTextoG("Dime cual es tu nick");
        try
        {
           enviaMensaje(Participante.nick); 
           //esperamos respuesta y la leemos
           /*
            * Tenemos que leer la confirmacion(OK)
            * como no tengo ninguna funcion para leer los mensajes recibidos;
            * porque de eso se encargara el escuchador, utilizares IOleeLinea
            */
           confirmacion=IO.leeLinea(Participante.entrada);           
           //si la respuesta no es OK se acaba
           if(confirmacion.equals("OK")==false)
           {
               Utilidades.muestraMensajeG("ERROR: en inicio de sesion");
               acabar();
           }
        }
        catch(IOException ex)
        {
            Utilidades.muestraMensajeG("ERROR en confirmacion de nick");
            acabar();
        }        
    }
    
    
    private static void leeYEnvia() {
        String linea;
        do {//el bucle lo utilizares para enviar o no mensajes
            // lee un mensaje del usuario
            linea = Utilidades.leerTextoG("¡Escribe un mensaje " + nick + " ! ");
            if((linea!=null)&&(linea.length()>0)&&(!linea.equals("SALIR")))
            {   //|                             |
                //no haria falta ponerlo,porque
                //la funcion enviaMensaje ya lo
                //hace internamente
                   enviaMensaje(linea);     
            }
        }
        while((linea!=null)&&(!linea.equals("SALIR")));//el bucle es con ;
        //este bucle sirve ppara seguir o no con el programa        
        enviaMensaje("SALIR");
        } 
    
    
    public static void enviaMensaje(String mensaje) 
    {
        if (mensaje == null || mensaje.length() == 0) 
        {
            return;
        }
        try 
        {
            IO.escribeLinea(mensaje, salida);
        }
        catch (IOException ex)
        {
        // si no puedo enviar mensajes, acabo
            acabar();
        }
    }
    
    static void acabar() 
    {
        if (elSocket == null) 
        {
        // Si elSocket es null, simplemente acabo.
        // Lo compruebo, por si llaman
        // a acabar() antes haber abierto la conexión
        //
            System.exit(0);
        }
        try 
        {
        // si el socket no es null cierro todo y paro el
        // thread del escuchador
            miEscuchador.parar();
            entrada.close();
            salida.close();
            elSocket.close();
            elSocket = null;
            Utilidades.muestraMensajeC("* Hasta luego !");
            System.exit(0);
        } 
        catch (Exception ex) 
        {
        }
    } // ()
    
    
    public static void main(String [] args)
    {
        obtenerIpPuerto();
        abrirConexion();
        iniciarSesion();
        miEscuchador=new Escuchador(entrada);//canal por el que recibe msj,esta 
        //funcion necesariamente tiene que ir antes de empezar a enviar msj,porque 
        //sino nos meteremos dentro del buclede enviar mensajes
        leeYEnvia();
        acabar();
        /*
         * Si no llamamos a acabar,se nos quedara colgado el programa.
         * El programa acabara,pero elSocket se quedara abierto
         */
    }
}    
