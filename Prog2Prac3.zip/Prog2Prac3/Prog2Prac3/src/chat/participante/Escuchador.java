/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.participante;

import chat.servidor.IO;
import java.io.IOException;
import java.io.InputStream;
import util.Utilidades;

/**
 *
 * @author Gema
 */
public class Escuchador implements Runnable
{
    private InputStream entrada;
    private boolean seguir;
    
    public Escuchador(InputStream esc)
    {
        this.entrada=esc;
        seguir=true;
        Thread th=new Thread(this);
        th.start();
    }
    
    public void run()
    {
        try
        {
            while(seguir==true)
            {
                String linea=recibeMensaje();
                Utilidades.muestraMensajeC(linea);
            }
        }
        catch(IOException ex)
        {
            Participante.acabar();
            /*
             * la funcion acabar cierra todo los sockets, pero a parte tenemos
             * que acabar el programa,y para ello utiliza la funcion parar
             */
        }
    }
    
    public void parar()
    {
        this.seguir=false;
    }
    
    private String recibeMensaje() throws IOException 
    {
        return IO.leeLinea(this.entrada);
    }
}
