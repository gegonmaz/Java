package p2;
//------------------------------------------------------------------------------
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E1 {
    //.........................................................................
    //coge el valor de la casilla del array y calcula su cuadrado
    //.........................................................................
    public static void main(String[] args) {
        int n = Utilidades.leerEntero("dime el tamaño");
        double[] numeros = new double[n];//creamos el array
        for (int i = 0; i <= numeros.length - 1; i++) {
            /*
             * Recorremos el array teniendo en cuenta que empezamos en la
             * casilla 0,con lo cual tendremos que restarle uno al valor del
             * tamaño del array EJ. tenemos un array de 7 casillas;entonces va
             * desde la 0 hasta la 6, por eso tenemos que recorrer desde la 0
             * hata la 6 y no hasta la 7, porque en ese lugar estariamos
             * recorriendo un array de 8 casillas.
             */
            numeros[i] = i * i;
        }
        for (double x : numeros) {
            System.out.println(x);
        }

    } // ()
} // class
