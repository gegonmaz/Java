package p2;
/*
 * @author Gema
 */
public class EjProp5 {
    public static void main(String[] args)
    {
        int l=Utilidades.leerEntero("Dime cuantos numeros");
        int [] numeros=new int [l];
        for(int i=0;i<=numeros.length-1;i++)
        {
            numeros[i]=Utilidades.leerEntero("Dime un numero");
        }
        for(int i=0;i<=numeros.length-1;i++)
        {
            if(numeros[i] == numeros[i+1])
            {
                if(numeros[i+1] == numeros[i+2])
                {
                System.out.print("El numero " + numeros[i]);
                System.out.println(" se repite en las casillas " + i);
                }          
            }
        }       
    }   
}
