package p2;
// @author Gema
public class EjProp4 {
    //..........................................................................
     /* Obtener un array de enteros del cual se muestre la suma de los numeros de 
     * los indices pares y la suma de los numeros de los indices impares     */
    //..........................................................................
    public static void main (String[]args){
        int l=Utilidades.leerEntero("Dime cuantos numeros quieres");
        int numeros[]=new int [l];
        int sumaPares=0;
        int sumaImpares=0;
        for(int i=0;i<=numeros.length-1;i++)
        {
            numeros[i]=Utilidades.leerEntero("Dime un numero");
            if(i%2==0)
            {
               sumaImpares=sumaImpares+numeros[i]; 
            }
            else
            {
                sumaPares=sumaPares+numeros[i];
            }
        }
        System.out.println("La suma de los indices pares es: " + sumaPares);
        System.out.println("La suma de los numeros impares es: " + sumaImpares);
    }   
}
