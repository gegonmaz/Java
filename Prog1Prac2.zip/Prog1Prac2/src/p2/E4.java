package p2;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E4 {

    //.........................................................................
    //Escribe en consola los números reales de un array que sean mayores
    //que otro de refencia
    //.........................................................................
    public static void main(String[] args) {
        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");
        //creamos array y le introducimos los valores
        double[] valores = Utilidades.leerArrayDeReales("Dime los numeros separados por espacios");
        //hacemos la comprobación de que se haya rellenado el array
        if (valores.length==0){
            Utilidades.muestraMensaje("No has escrito nada");
            System.out.println("Nos has escrito nada");
        }
        double referencia = Utilidades.leerReal("Dime un real");
        //recorremos el array de valores
        for (double x : valores) {
            //si el valor guardado en la casilla del array es mayor que la referncia
            //lo imprime por pantalla
            if (x > referencia) {
                System.out.println(x);
            }
        }
    } // ()
} // class

