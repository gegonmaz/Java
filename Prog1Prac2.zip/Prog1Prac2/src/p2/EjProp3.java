package p2;

/**
 *
 * @author Gema
 */
public class EjProp3 {
    //..........................................................................
            /*
             * escribir dos arrays que guarden enteros;escribir un tercero que 
             * guarde en cada una de sus casillas la suma de las correspondientes
             * casillas de los dos primeros,y un cuarto array que guarde las restas
             */
    //..........................................................................

    public static void main(String[] args) {
        int l = Utilidades.leerEntero("Cuantos numeros quieres");
        int bloque1[] = new int[l];
        int bloque2[] = new int[l];
        int bloqueSuma[] = new int[l];
        int bloqueResta[] = new int[l];
        
        for(int i=0;i<=bloqueSuma.length-1;i++)
        {
            bloque1[i]=Utilidades.leerEntero("Dime un numero del primer bloque");
            bloque2[i]=Utilidades.leerEntero("Dime un numero del segundo bloque");
            bloqueSuma[i]=bloque1[i]+bloque2[i];
            System.out.println("En la casilla " + i + " encontramos " + bloqueSuma[i] );
        }
        System.out.println();
        for(int x=0;x<=bloqueResta.length-1;x++)
        {
            bloque1[x]=Utilidades.leerEntero("Dime un numero del primer bloque");
            bloque2[x]=Utilidades.leerEntero("Dime un numero del segundo bloque");
            bloqueResta[x]=bloque1[x]-bloque2[x];
            
            System.out.println("en la casilla " + x + " encontramos " + bloqueResta[x]);
        }      
        }
    }

