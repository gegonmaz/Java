package p2;

//------------------------------------------------------------------------------
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E2 {

    //.........................................................................
    //pide los reales y los compara,y luego te dice cual es el menor y en 
    //que casilla se encuentra
    //.........................................................................
    public static void main(String[] args) {
        //creamos array 
        double[] valores;
        //y guadamos los valores de las casillas
        valores = Utilidades.leerArrayDeReales("escribe números reales separados por espacio");
        //si el tamaño del array es igual a cero muestra mensaje
        if (valores.length == 0) {
            Utilidades.muestraMensaje("¿no has escrito nada?");
            return;
        }
        //creamos variable  posicion del menor
        int posMenor = 0;
        //volvemos a recorrer array
        for (int i = 0; i <= valores.length - 1; i++) {
            /*
             * comparamos si el valor que hay en la casilla 0 del array es mayor
             * que el valor de la siguiente casilla,si lo es, entonces la
             * variable posMenor pasa a valer el valor que habia en la casilla,y
             * sino es mayor,posMenor sigue valiendo lo mismo.
             */
            if (valores[posMenor] > valores[i]) {
                posMenor = i;
            }
        }

        Utilidades.muestraMensaje("el menor es el " + valores[posMenor] + " y esta en la casilla " + posMenor);
    } // ()
} // class
