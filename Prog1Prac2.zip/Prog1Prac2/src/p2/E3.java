package p2;

import javax.swing.JOptionPane;

//------------------------------------------------------------------------------
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E3 {

    //.........................................................................
    //calcula la media de los números reales guardados en un array
    //.........................................................................
    public static void main(String[] args) {
        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");
        //creamos el array y guardamos los valores en las casillas

        double[] valores = Utilidades.leerArrayDeReales("Escribe los números separados por espacios");
        //hacemos la comprobación de que se haya rellenado el array
        if (valores.length == 0) {
            Utilidades.muestraMensaje("No has escrito nada");
            System.out.println("Nos has escrito nada");
        }
        //inicializamos la variable sum a 0
        double sum = 0;
        //recorremos el array de valores y sumamos los valores que guarda cada casilla
        for (double x : valores) {
            sum = sum + x;
        }
        //mostramos por pantalla la suma de los valores dividida por el tamño del array
        //es decir, por el numero de valores que hay
        Utilidades.muestraMensaje("La media es:  " + sum / valores.length);
    } // ()
} // class
