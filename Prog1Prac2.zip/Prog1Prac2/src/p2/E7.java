package p2;

//------------------------------------------------------------------------------
//Gema GOnzález Mazarías
//------------------------------------------------------------------------------
public class E7 {

    //.........................................................................
    // calcular la distancia de un camino de n puntos
    //.........................................................................
    public static void main(String[] args) {

        //JOptionPane.showMessageDialog(null, " no esta resuelto aún ");

        int nPuntos = Utilidades.leerEntero("dime cuántos puntos:");
        Punto[] losPuntos = new Punto[nPuntos];


        for (int i = 0; i <= losPuntos.length - 1; i++) {
            losPuntos[i] = Utilidades.leePunto(" dime coordenadas del punto " + i + " (separadas por espacio en blanco)");
        }

        double sum = 0;
        //calculamos la suma de las distancias de un punto con otro
        for (int i = 0; i <= losPuntos.length - 2; i++) {
            /*
             * Ej.tamaño del array 6 lee de la casilla 0 hasta la 5 descontamos:
             * 1 porque empezamos a leer en la casilla 0 y no en la 1 1 porque a
             * la ultima casilla no le podemmos sumar nada,porque no hay mas
             * puntos para sumar.
             */
            sum = sum + losPuntos[i].distancia(losPuntos[i + 1]);
        }
        System.out.println("La suma del camino es: " + sum);
    } // ()
} // class

