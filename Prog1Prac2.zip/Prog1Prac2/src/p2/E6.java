package p2;
//------------------------------------------------------------------------------
//Gema González Mazarías
//------------------------------------------------------------------------------
public class E6 {
    //.........................................................................
    //calcula la distancia de cada punto,guardado en el array,al punto de origen
    //.........................................................................

    public static void main(String[] args) {
        //creamos array del tamaño d nPuntos
        int nPuntos = Utilidades.leerEntero("dime cuántos puntos:");

        Punto[] losPuntos = new Punto[nPuntos];
        //creamos el punto de origen (0.0)
        Punto origen = new Punto();
        //guardamos en cada casilla del array un punto
        for (int i = 0; i <= losPuntos.length - 1; i++) {
            losPuntos[i] = Utilidades.leePunto(" dime coordenadas del punto " + i + " (separadas por espacio en blanco)");
        }                //calculamos la distancia de cada uno de los punto guardados 
        //al punto de origen
        for (int i = 0; i <= losPuntos.length - 1; i++) {
            double d = losPuntos[i].distancia(origen);
            Utilidades.muestraPunto("" + d + " es distancia al origen del punto: ", losPuntos[i]);
        }
    } // ()
} // class

