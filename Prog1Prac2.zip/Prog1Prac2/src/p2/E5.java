package p2;
//------------------------------------------------------------------------------
public class E5 {

    //.........................................................................
    // lee dos puntos, los suma y muestra la distancia de uno a otro.
    //.........................................................................
    public static void main(String[] args) {
        //creamos punto a y b
        Punto a = Utilidades.leePunto("dime las coordenadas de un punto (separadas por espacio en blanco)");
        Punto b = Utilidades.leePunto("dime las coordenadas de otro punto (separadas por espacio en blanco)");
        //los mostramos por pantalla
        Utilidades.muestraPunto("el punto a es: ", a);
        Utilidades.muestraPunto("el punto b es: ", b);
        //creamos otro punto c que valga la suma del punto a con el pto b
        Punto c = a.suma(b);
        //mostramos el resultado de la suma
        Utilidades.muestraPunto("la suma a + b es: ", c);
        //mostramos la distancia entre a y b
        Utilidades.muestraMensaje("la distancia entre a y b es: " + a.distancia(b));
    } // ()
} // class

