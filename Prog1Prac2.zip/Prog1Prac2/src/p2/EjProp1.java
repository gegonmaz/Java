/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author Gema
 */
public class EjProp1 {
    //..........................................................................
        /*
         * leer un array de enteros.Mostrar un mensaje indicando la suma,la media
         * y la desviacion tipica de todos los enteros del array.
         */
    //..........................................................................

    public static void main(String[] args) {
        
        int l = Utilidades.leerEntero("Cuantos numeros quieres");
        int[] valores = new int[l];
        int sum = 0;
        int media;
        double desviacion = 0;
        
        for (int i = 0; i <= valores.length - 1; i++) 
        {
            valores[i] = Utilidades.leerEntero("Dime un numero");

            sum = sum + valores[i];
        }
        
        media = sum / valores.length;
        
        for(int x:valores)
        {
            
            desviacion=(desviacion +Math.pow((x-media),2));
        }

        System.out.print(" La suma de los valores es: " + sum);
        System.out.print(" La media es: " + media);
        System.out.println(" La desviacion tipica es: " + Math.sqrt(desviacion/valores.length));
    }
}
