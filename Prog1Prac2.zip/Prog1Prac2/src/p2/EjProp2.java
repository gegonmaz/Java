package p2;

/**
 *
 * @author Gema
 */
public class EjProp2 {
    //..........................................................................
        /*
     * Obtener un array de enteros y mostrar un mensaje indicando cual es la
     * distancia entre cada elemento y el siguiente
     */
    //..........................................................................
    public static void main(String[] args) {
        int l = Utilidades.leerEntero("Cuantos numeros quieres");
        int[] valores = new int[l];
        int dist;
        for (int i = 0; i <= valores.length - 1; i++)
        {
            valores[i] = Utilidades.leerEntero("Dime un numero");
        }
        for (int i = 0; i <= valores.length - 2; i++) 
        {
            dist = (valores[i + 1] - valores[i]);
            System.out.println("La distancia de un numero a otro es: " + dist);
        }

    }
}
